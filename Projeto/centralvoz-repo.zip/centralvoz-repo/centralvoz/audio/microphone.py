"""Captura de audio em streaming.

O codigo antigo usava `sd.rec()`, que grava um bloco de duracao fixa e so
entrega tudo no final. Isso e ruim para comando de voz: voce fica esperando o
tempo acabar mesmo tendo dito "ligar led" em meio segundo.

Aqui usamos `RawInputStream`, que entrega blocos de ~250 ms enquanto voce fala.
Assim da para mostrar o resultado parcial no LCD e reagir assim que o botao e
solto. Nao depende de numpy: trabalhamos com bytes crus (PCM 16 bits).
"""

from __future__ import annotations

import logging
import queue
import wave
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from ..config import AudioConfig
from ..utils import ensure_dir, timestamp_slug

logger = logging.getLogger(__name__)

SAMPLE_WIDTH_BYTES = 2  # int16


class AudioUnavailable(RuntimeError):
    """Sem microfone ou sem a biblioteca de audio."""


def _import_sounddevice():
    try:
        import sounddevice  # noqa: PLC0415
    except ImportError as exc:
        raise AudioUnavailable(
            "sounddevice nao instalado.\n"
            "    sudo apt install -y libportaudio2\n"
            "    pip install sounddevice"
        ) from exc
    except OSError as exc:  # PortAudio ausente no sistema
        raise AudioUnavailable(
            f"PortAudio nao encontrado ({exc}). Rode: sudo apt install -y libportaudio2"
        ) from exc
    return sounddevice


def list_input_devices() -> list[dict]:
    """Dispositivos de entrada disponiveis. Usado por `voz devices`."""
    sd = _import_sounddevice()
    devices = []
    for index, info in enumerate(sd.query_devices()):
        if info.get("max_input_channels", 0) > 0:
            devices.append(
                {
                    "index": index,
                    "name": info.get("name", "?"),
                    "channels": info.get("max_input_channels"),
                    "default_samplerate": info.get("default_samplerate"),
                }
            )
    return devices


class Microphone:
    """Fonte de blocos de audio PCM 16 bits mono."""

    def __init__(self, config: AudioConfig) -> None:
        self.config = config
        self._sd = None

    def check(self) -> None:
        """Levanta AudioUnavailable cedo, com mensagem util."""
        self._sd = _import_sounddevice()
        try:
            self._sd.check_input_settings(
                device=self.config.input_device,
                channels=self.config.channels,
                samplerate=self.config.sample_rate,
                dtype="int16",
            )
        except Exception as exc:  # noqa: BLE001
            raise AudioUnavailable(
                f"O microfone nao aceita {self.config.sample_rate} Hz mono int16 ({exc}).\n"
                "Liste os dispositivos com `voz devices` e escolha um em config.toml:\n"
                "    [audio]\n    input_device = 1"
            ) from exc

    @contextmanager
    def stream(self) -> Iterator[queue.Queue]:
        """Abre o microfone e entrega uma fila de blocos (bytes)."""
        sd = self._sd or _import_sounddevice()
        blocks: queue.Queue = queue.Queue()

        def callback(indata, _frames, _time, status) -> None:
            if status:
                logger.debug("Status do stream de audio: %s", status)
            blocks.put(bytes(indata))

        stream = sd.RawInputStream(
            samplerate=self.config.sample_rate,
            blocksize=self.config.block_size,
            device=self.config.input_device,
            dtype="int16",
            channels=self.config.channels,
            callback=callback,
        )
        with stream:
            logger.debug("Microfone aberto (%d Hz)", self.config.sample_rate)
            yield blocks


def save_wav(chunks: list[bytes], directory: Path, config: AudioConfig) -> Path:
    """Grava o audio capturado em .wav (util para depurar reconhecimento ruim)."""
    ensure_dir(directory)
    path = directory / f"audio_{timestamp_slug()}.wav"
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(config.channels)
        handle.setsampwidth(SAMPLE_WIDTH_BYTES)
        handle.setframerate(config.sample_rate)
        handle.writeframes(b"".join(chunks))
    return path


def duration_of(chunks: list[bytes], config: AudioConfig) -> float:
    total_bytes = sum(len(chunk) for chunk in chunks)
    frames = total_bytes / (SAMPLE_WIDTH_BYTES * max(1, config.channels))
    return frames / config.sample_rate
